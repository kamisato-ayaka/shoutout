export type LikeVars = {
    user: string
}