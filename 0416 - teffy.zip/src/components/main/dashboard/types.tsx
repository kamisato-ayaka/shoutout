export type DashboardVars = {
    userName: string 
}

export type PostVars = {
    username: string 
    post: string
    comments: string
    likes: string
}