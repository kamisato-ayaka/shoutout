import * as actionType from './strings'
import { LoginVars } from '../components/signup/types'

export const addUser = (newUser: LoginVars) => {
    return {
        type: actionType.ADD_USER,
        payload: newUser
    }
}