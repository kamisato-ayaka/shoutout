import * as actionType from "../strings";
import { LoginVars } from "../../components/signup/types";

const userData = localStorage.getItem("user");
const initUser: LoginVars[] = userData == null ? [] : JSON.parse(userData);

const reduce = (state: LoginVars[] = initUser, action: any) => {
  switch (action.type) {
    case actionType.ADD_USER:
      return [...state, action.payload];
    default:
      return state;
  }
};

const signupReducer = (state: LoginVars[] = initUser, action: any) => {
  const newState: LoginVars[] = reduce(state, action);
  localStorage.setItem("user", JSON.stringify(newState));
  return newState;
}

export default signupReducer;
