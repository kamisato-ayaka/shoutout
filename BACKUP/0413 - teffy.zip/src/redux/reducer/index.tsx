import { combineReducers } from "redux";
import signupReducer from './signupReducer'

const reducer = combineReducers({
    signupReducer
})

export default reducer