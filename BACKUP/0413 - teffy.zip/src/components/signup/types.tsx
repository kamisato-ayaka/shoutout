export type LoginVars = {
    username: string,
    password: string
    confirmpassword: string
}