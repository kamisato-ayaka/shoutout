import React from 'react'

const Login = () => {
  return (
    <>
    <button>Log In</button>
    </>
  )
}

export default Login