import React from 'react';
import './App.css';
import SignUp from './components/signup';


const App = () => {
  return (
    <div className="App">
      <SignUp />
    </div>
  );
}

export default App;
