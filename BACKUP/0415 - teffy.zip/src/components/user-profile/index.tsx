import React, { useMemo } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { PostVars, DashboardVars } from '../main/dashboard/types'
import { UsernameVar, followUser } from '../../redux/actions'

const UserProfile: React.FC<DashboardVars> = ({
  userName
}) => {
  const dispatch = useDispatch()
  const postList: PostVars[] = useSelector((state: any) => state.postReducer)
  const user: UsernameVar = useSelector((state: any) => state.getUserReducer)

  const findUser: PostVars[] = postList.filter((val: PostVars) => val.username === user)

  const userProfile = useMemo(() => {
    return (
      <ul>
        {findUser.map((val: PostVars, index: any) => <li key={index}>{val.post} - {val.username}</li>)}
      </ul>
    )
  }, [findUser])

  const follow = () => {
    const newFollow = {
      username: userName,
      followuser: [user]
    }
    dispatch(followUser(newFollow))
  }

  return (
    <>
      <h1>{user}</h1>
      <button onClick={() => follow()}>Follow</button>
      {userProfile}
    </>
  )
}

export default UserProfile