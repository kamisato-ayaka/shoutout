export type FollowVars = {
    username: string,
    followuser: string[],
}
