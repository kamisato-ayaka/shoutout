import React from 'react'
import { DashboardVars } from './types';
import PostForm from '../post-form';
import PostList from '../post-list';
import Setting from '../setting';
import { useSelector } from 'react-redux';
import UserProfile from '../../user-profile';

const Dashboard: React.FC<DashboardVars> = ({
  userName
}) => {

  const gotoUserProfile = useSelector((state: any) => state.toUserProfileReducer)

  return (
    <>
      <h1 >Shoutout</h1>
      <p>Hi, {userName}</p>

      {!gotoUserProfile ? <>
        <PostForm userName={userName} />
        <PostList />
      </> : <UserProfile userName={userName}/>
      }

      <Setting />
    </>
  )
}

export default Dashboard