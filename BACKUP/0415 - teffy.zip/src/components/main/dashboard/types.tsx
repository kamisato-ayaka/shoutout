export type DashboardVars = {
    userName: string 
}

export type PostVars = {
    username: string 
    post: string
    views: string
    likes: string
}