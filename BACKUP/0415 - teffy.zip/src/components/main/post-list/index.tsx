import React, { useMemo } from 'react'
import { PostVars } from '../dashboard/types'
import { useSelector, useDispatch } from 'react-redux'
import { toUserProfile, getUser, UsernameVar } from '../../../redux/actions'

const PostList = () => {
  const dispatch = useDispatch()
  const postList: PostVars[] = useSelector((state: any) => state.postReducer)

  const post = useMemo(() => {
    return postList.map((val: PostVars, index: any) => {
      const user: UsernameVar = val.username

      return (
        <li key={index} onClick={() => {
          dispatch(toUserProfile())
          dispatch(getUser(user))
        }
        }>{val.post} - {user}</li>
      )
    })
  }, [dispatch, postList])

  return (
    <ul>
      {post}
    </ul>
  )
}

export default PostList