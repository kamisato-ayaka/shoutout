export type DashboardVars = {
    userName: string | undefined
}

export type PostVars = {
    username: string | undefined
    post: string
    views: string
    likes: string
}