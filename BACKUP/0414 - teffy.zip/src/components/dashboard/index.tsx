import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { toLogin, addPost } from '../../redux/actions'
import { Formik } from 'formik'
import { DashboardVars, PostVars } from './types';

const Dashboard: React.FC<DashboardVars> = ({
  userName
}) => {
  const dispatch = useDispatch();
  const postList: PostVars[] = useSelector((state: any) => state.postReducer)
  const initialValues: PostVars = {
    username: '',
    post: '',
    views: '',
    likes: ''
  }

  const onSubmit = (values: PostVars, { resetForm }: any) => {
    const newPost = {
      username: userName,
      post: values.post,
      views: values.views,
      likes: values.likes
    }
    dispatch(addPost(newPost))
    resetForm()
  }

  return (
    <>
      <h1>Shoutout</h1>
      <p>Hi, {userName}</p>

      <Formik
        initialValues={initialValues}
        onSubmit={onSubmit}>
        {
          formik => (
            <>
              <form onSubmit={formik.handleSubmit}>
                <div>
                  <input
                    type="text"
                    name="post"
                    placeholder="Post your shoutout!"
                    value={formik.values.post}
                    onBlur={formik.handleBlur}
                    onChange={formik.handleChange}
                  />
                  {formik.touched.post && formik.errors.post ? (
                    <div>{formik.errors.post}</div>
                  ) : null}
                </div>
                <button type="submit">Post</button>
              </form>
            </>
          )
        }
      </Formik>
      <ul>
        {
          postList.map((val: PostVars, index: any) => {
            return (
              <li key={index}>{val.post} - {val.username}</li>
            )
          })
        }
      </ul>

      <button onClick={() => dispatch(toLogin())}>Log Out</button>
    </>
  )
}

export default Dashboard