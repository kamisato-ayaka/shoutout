export type UserVars = {
    username: string,
    password: string
    confirmpassword: string
}