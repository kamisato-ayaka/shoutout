export const TO_SIGNUP = "TO_SIGNUP"
export const TO_LOGIN = "TO_LOGIN"

export const ADD_USER = "ADD_USER"
export const ADD_POST = "ADD_POST"