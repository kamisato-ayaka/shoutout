import { combineReducers } from "redux";
import signupReducer from './signupReducer'
import toSignupReducer from './toSignupReducer'
import toLoginReducer from './toLoginReducer'
import postReducer from './postReducer'

const reducer = combineReducers({
    signupReducer,
    toSignupReducer,
    toLoginReducer,
    postReducer
})

export default reducer