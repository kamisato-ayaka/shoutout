import * as actionType from './strings'
import { UserVars } from '../components/signup/types'
import { PostVars } from '../components/dashboard/types'

export const toSignup = () => {
    return {
        type: actionType.TO_SIGNUP
    }
}

export const toLogin = () => {
    return {
        type: actionType.TO_LOGIN
    }
}

export const addUser = (newUser: UserVars) => {
    return {
        type: actionType.ADD_USER,
        payload: newUser
    }
}

export const addPost = (newPost: PostVars) => {
    return {
        type: actionType.ADD_POST,
        payload: newPost
    }
}