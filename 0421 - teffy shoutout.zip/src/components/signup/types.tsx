export type UserVars = {
    username: string,
    password: string
    confirmpassword: string
    following: Array<string>
    followers: Array<string>
}