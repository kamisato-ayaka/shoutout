export type PostVars = {
    id: number
    username: string 
    post: string
    comments: Array<string>
    likes: Array<string>
}